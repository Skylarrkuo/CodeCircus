<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
}
</script>

<style>
@import './assets/styles.css'; /* 引入自定义样式 */
</style>
