import { createRouter, createWebHistory } from 'vue-router';
import Login from './components/Login.vue';
import Register from './components/Register.vue';
import ForgotPassword from './components/ForgotPassword.vue';
import UserDashboard from './components/UserDashboard.vue'; // 更新引入的组件名称

const routes = [
  { path: '/', component: Login },
  { path: '/register', component: Register },
  { path: '/forgot-password', component: ForgotPassword },
  { path: '/UserDashboard', component: UserDashboard } // 更新路由指向的组件名称
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
