<template>
  <div class="dashboard">
    <!-- 菜单 -->
    <nav class="menu">
      <ul>
        <li v-for="(item, index) in menuItems" :key="index">{{ item }}</li>
      </ul>
    </nav>

    <h2>欢迎来到用户仪表板</h2>

    <!-- Swiper 轮播图 -->
    <swiper
      :slides-per-view="1"
      :navigation="true"
      :pagination="{ clickable: true }"
      :loop="true"
      :autoplay="{ delay: 3000 }"
      class="swiper-container"
    >
      <swiper-slide v-for="(slide, index) in slides" :key="index" class="swiper-slide">
        <img :src="slide.image" :alt="slide.title" class="slide-image" />
        <p>{{ slide.title }}</p>
      </swiper-slide>
    </swiper>

    <!-- 登出按钮 -->
    <router-link to="/">登出</router-link>
  </div>
</template>

<script>
import { Swiper, SwiperSlide } from 'swiper/vue'; // 导入 Swiper 组件
import { Autoplay } from 'swiper/modules'; // 导入 Autoplay 模块
import 'swiper/swiper-bundle.css'; // 导入 Swiper 样式
import 'swiper/css/autoplay'; // 导入 Autoplay 样式

export default {
  name: 'UserDashboard',
  components: {
    Swiper,
    SwiperSlide
  },
  data() {
    return {
      slides: [
        { image: require('@/assets/images/slide1.jpg'), title: 'Slide 1' },
        { image: require('@/assets/images/slide2.jpg'), title: 'Slide 2' },
        { image: require('@/assets/images/slide3.jpg'), title: 'Slide 3' }
      ],
      menuItems: ['主页', '设置', '帮助', '关于']
    };
  },
  // 注册 Autoplay 模块
  install: [Autoplay],
}
</script>

<style scoped>
.dashboard {
  text-align: center;
  margin-top: 20px;
}

.menu {
  background-color: #f8f8f8;
  padding: 10px 0;
  border-bottom: 1px solid #ddd;
}

.menu ul {
  list-style-type: none;
  padding: 0;
  display: flex;
  justify-content: center;
  margin: 0;
}

.menu li {
  margin: 0 15px;
  cursor: pointer;
  font-weight: bold;
}

.swiper-container {
  width: 100%;
  max-width: 640px;
  height: auto;
  margin: 20px auto;
}

.swiper-slide {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.slide-image {
  width: 100%;
  height: auto;
  object-fit: cover;
  border-radius: 10px;
}
</style>
