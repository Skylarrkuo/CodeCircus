<template>
  <div class="container">
    <h2>登录</h2>
    <form @submit.prevent="handleLogin">
      <div>
        <label for="username">用户名:</label>
        <input type="text" v-model="username" id="username" required />
      </div>
      <div>
        <label for="password">密码:</label>
        <input type="password" v-model="password" id="password" required />
      </div>
      <!-- 将按钮放在单独的div中 -->
      <div class="button-container">
        <button type="submit">登录</button>
      </div>
    </form>
    <div v-if="message" :class="{'success': isSuccess, 'error': !isSuccess}">
      {{ message }}
    </div>
    <div class="options">
      <router-link to="/register">注册</router-link>
      <router-link to="/forgot-password">忘记密码？</router-link>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'; // 导入 useRouter

export default {
  name: 'LoginForm',
  data() {
    return {
      username: '',
      password: '',
      message: '',
      isSuccess: false
    };
  },
  setup() {
    const router = useRouter(); // 获取路由实例
    return { router };
  },
  methods: {
    handleLogin() {
      if (this.username === 'admin' && this.password === '123456') {
        this.message = '登录成功！';
        this.isSuccess = true;
        this.router.push('/UserDashboard'); // 登录成功后重定向到 UserDashboard
      } else {
        this.message = '用户名或密码错误，请重试。';
        this.isSuccess = false;
      }
      this.username = '';
      this.password = '';
    }
  }
}
</script>


<style scoped>
.container {
  background-color: white; /* 容器背景颜色为白色 */
  padding: 20px; /* 内边距为20px */
  border-radius: 5px; /* 边角圆滑 */
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* 添加阴影效果 */
  width: 300px; /* 设置容器宽度为300px */
  margin: auto; /* 居中对齐 */
}

.button-container {
  margin-top: 20px; /* 按钮顶部外边距 */
}

h2 {
  text-align: center; /* 标题居中对齐 */
}

.success {
  color: green; /* 成功消息颜色 */
}

.error {
  color: red; /* 错误消息颜色 */
}
</style>
