<template>
    <div class="container">
      <h2>忘记密码</h2>
      <form @submit.prevent="handleForgotPassword">
        <div>
          <label for="email">请输入您的邮箱:</label>
          <input type="email" v-model="email" id="email" required />
        </div>
        <div class="button-container">
            <button type="submit">发送重置链接</button>
        </div>
      </form>
      <div class="options">
        <router-link to="/">返回登录</router-link>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'ForgotPasswordForm', // 更新组件名称为多单词
    data() {
      return {
        email: ''
      };
    },
    methods: {
      handleForgotPassword() {
        alert(`重置链接已发送到 ${this.email}`);
        this.email = '';
      }
    }
  }
  </script>
  
  <style scoped>
  .container {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px;
    margin: auto;
  }
  .button-container {
  margin-top: 20px; /* 按钮顶部外边距 */
  }
  </style>
  