<template>
    <div class="container">
      <h2>注册</h2>
      <form @submit.prevent="handleRegister">
        <div>
          <label for="new-username">用户名:</label>
          <input type="text" v-model="newUsername" id="new-username" required />
        </div>
        <div>
          <label for="new-password">密码:</label>
          <input type="password" v-model="newPassword" id="new-password" required />
        </div>
        <div>
          <label for="confirm-password">确认密码:</label>
          <input type="password" v-model="confirmPassword" id="confirm-password" required />
        </div>
        <div class="button-container">
            <button type="submit">注册</button>
        </div>
      </form>
      <div class="options">
        <router-link to="/">返回登录</router-link>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'RegisterForm', // 更新组件名称为多单词
    data() {
      return {
        newUsername: '',
        newPassword: '',
        confirmPassword: ''
      };
    },
    methods: {
      handleRegister() {
        if (this.newPassword === this.confirmPassword) {
          alert('注册成功！');
          this.newUsername = '';
          this.newPassword = '';
          this.confirmPassword = '';
        } else {
          alert('密码不匹配，请重试。');
        }
      }
    }
  }
  </script>
  
  <style scoped>
  .container {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px;
    margin: auto;
  }
  .button-container {
  margin-top: 20px; /* 按钮顶部外边距 */
  }
  </style>
  