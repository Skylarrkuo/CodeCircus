public class CPU {
    static int speed;
    void setSpeed(int m) {
        speed = m;
    }
    int getSpeed() {
        return speed;
    }
}
