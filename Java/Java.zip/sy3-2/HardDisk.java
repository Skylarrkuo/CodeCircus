public class HardDisk {
    static int amount;
    void setAmount(int m) {
        amount = m;
    }
    int getAmount() {
        return amount;
    }
}
